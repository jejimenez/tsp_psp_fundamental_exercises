"""
Assignment1> Load the file with the values every. The file must be in the same directory with the name 
  >>> values.txt

"""
import math


class Node(object):
	
	def __init__(self, value=None, next=None):
		self.value = value
		self.next = next

	def get_value(self):
		return self.value

	def get_next(self):
		return self.next

	def set_next(self, next):
		self.next = next


class LinkedList(object):

	def __init__(self, head = None):
		self.head = head

	def add(self, value):
		print(value)
		node = Node(value, self.head)
		self.head = node

	def remove(self, value):
		current = self.head
		previous = None
		# search the node with the data. 
		# Keep in mind the previous to validate when it is head so point the new head
		while current:
			if current.get_value() == data:
				break
			else:
				previous = current
				current = current.get_next()
		if current is None:
			raise ValueError('No se encontró el elemento')
		if previous is None:
			self.head = current.get_next()
		else:
			previous.set_next(current.get_next())

	def get_prior(self):
		return self.head

	# Get the node next to the node with match with the value
	def get_next(self, value):
		current = self.head
		while current:
			if current.get_value() == value:
				return current.get_next()
			else:
				current = current.get_next()

		if current is None:
			raise ValueError('No se encontró el elemento')


print('App initiated...')
print('Loading file value.txt')
f = open('values.txt', 'r+')
print('File values.txt loaded')
n = 0
sum_val = 0
line_val = None
mean = None
dev = None
list_vals = LinkedList()
print('Loading values in LinkedList')
for line in f:
	if str(line).rstrip('\r') != '':
		n+=1
		try:
			line_val = float(str(line))
			list_vals.add(line_val)
		except ValueError:
			print('Error al intentar convertir el valor '+line+'.')
			raise ValueError('Imposible convertir el valor '+line+'.')
print('Calculating mean')
node = list_vals.get_prior()
while node:
	sum_val += node.get_value()
	node = list_vals.get_next(node.get_value())
mean = sum_val/n
#print('sum ='+str(sum_val))
print('MEAN = '+str(mean))
print('Calculating SD')
node = list_vals.get_prior()
sum_val = 0
while node:
	x = (node.get_value() - mean) * (node.get_value() - mean)
	sum_val+=x
	node = list_vals.get_next(node.get_value())
#print('Sumatoria (Xi-Xavg)^2 = '+str(sum_val))
dev = math.sqrt(sum_val/(n-1))
print('SD = '+str(dev))